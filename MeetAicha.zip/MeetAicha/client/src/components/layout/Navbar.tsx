import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import AichaLogo from "@/assets/AichaLogo";
import { Menu, X } from "lucide-react";
import { scrollToElement } from "@/hooks/use-smooth-scroll";
import { useActiveSection } from "@/hooks/use-active-section";

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const activeSection = useActiveSection();
  
  // Fonction pour vérifier si un lien est actif
  const isActive = (href: string): boolean => {
    // Pour les pages distinctes comme /blog
    if (!href.startsWith('/#')) {
      return location === href || (href === '/blog' && location.startsWith('/blog/'));
    }
    
    // Si nous ne sommes pas sur la page d'accueil, aucun lien d'ancrage ne doit être actif
    if (location !== '/') {
      return false;
    }
    
    // Extraire l'ID de la section à partir du href
    const sectionId = href.substring(2); // Enlever '/#'
    
    // Vérifier si cette section est active via l'Intersection Observer
    if (location === '/' && activeSection) {
      return sectionId === activeSection;
    } else {
      // Si pas de section active détectée et nous sommes sur la page d'accueil
      // "À propos" est actif par défaut
      return href === '/#about';
    }
  };

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };
  
  // Fonction pour gérer le défilement fluide lors du clic sur un lien de navigation
  const handleNavLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    // Seulement pour les liens internes avec ancres
    if (href.includes('#')) {
      e.preventDefault();
      
      // Fermer le menu mobile si ouvert
      if (isOpen) {
        setIsOpen(false);
      }
      
      // Si nous ne sommes pas sur la page d'accueil, rediriger d'abord vers la page d'accueil
      if (location !== '/') {
        window.location.href = href; // Redirection complète vers la page d'accueil avec l'ancre
      } else {
        // Si déjà sur la page d'accueil, utiliser le défilement fluide
        scrollToElement(href);
      }
    }
  };

  return (
    <nav className="bg-white shadow-md sticky top-0 z-50 transition-all duration-300">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <div className="h-14 w-14 rounded-full overflow-hidden">
                <AichaLogo />
              </div>
              <span className="ml-3 text-2xl font-bold gradient-text font-poppins">Aïcha</span>
            </Link>
          </div>
          
          <div className="hidden md:ml-6 md:flex md:items-center md:space-x-4">
            <a 
              href="/#about" 
              className={`text-gray-700 hover:text-white px-4 py-2 text-base font-medium rounded-full transition-all duration-300 hover:bg-gradient-to-r hover:from-[#FF7A47] hover:to-[#29ABA4] ${isActive("/#about") ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" : "hover:shadow-md"}`}
              onClick={(e) => handleNavLinkClick(e, "/#about")}
            >
              À propos
            </a>
            <a 
              href="/#skills" 
              className={`text-gray-700 hover:text-white px-4 py-2 text-base font-medium rounded-full transition-all duration-300 hover:bg-gradient-to-r hover:from-[#FF7A47] hover:to-[#29ABA4] ${isActive("/#skills") ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" : "hover:shadow-md"}`}
              onClick={(e) => handleNavLinkClick(e, "/#skills")}
            >
              Mes compétences
            </a>
            <a 
              href="/#help" 
              className={`text-gray-700 hover:text-white px-4 py-2 text-base font-medium rounded-full transition-all duration-300 hover:bg-gradient-to-r hover:from-[#FF7A47] hover:to-[#29ABA4] ${isActive("/#help") ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" : "hover:shadow-md"}`}
              onClick={(e) => handleNavLinkClick(e, "/#help")}
            >
              Comment je peux aider
            </a>
            <a 
              href="/#pricing" 
              className={`text-gray-700 hover:text-white px-4 py-2 text-base font-medium rounded-full transition-all duration-300 hover:bg-gradient-to-r hover:from-[#FF7A47] hover:to-[#29ABA4] ${isActive("/#pricing") ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" : "hover:shadow-md"}`}
              onClick={(e) => handleNavLinkClick(e, "/#pricing")}
            >
              Tarifs
            </a>
            <a 
              href="/#blog" 
              className={`text-gray-700 hover:text-white px-4 py-2 text-base font-medium rounded-full transition-all duration-300 hover:bg-gradient-to-r hover:from-[#FF7A47] hover:to-[#29ABA4] ${isActive("/#blog") ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" : "hover:shadow-md"}`}
              onClick={(e) => handleNavLinkClick(e, "/#blog")}
            >
              Blog
            </a>
            <a 
              href="/#contact" 
              className={`text-gray-700 hover:text-white px-4 py-2 text-base font-medium rounded-full transition-all duration-300 hover:bg-gradient-to-r hover:from-[#FF7A47] hover:to-[#29ABA4] ${isActive("/#contact") ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" : "hover:shadow-md"}`}
              onClick={(e) => handleNavLinkClick(e, "/#contact")}
            >
              Contact
            </a>
          </div>
          
          <div className="flex items-center md:hidden">
            <button
              type="button"
              onClick={toggleMenu}
              className={`inline-flex items-center justify-center p-2.5 rounded-full transition-all duration-300 ${
                isOpen 
                  ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" 
                  : "text-gray-700 hover:text-[#FF7A47] hover:bg-gradient-to-r hover:from-[#FF7A47]/10 hover:to-[#29ABA4]/10 hover:shadow-sm"
              } focus:outline-none`}
            >
              <span className="sr-only">Open main menu</span>
              {isOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden bg-white pt-4 pb-6 px-6 shadow-md rounded-b-xl">
          <div className="flex flex-col space-y-3">
            <a 
              href="/#about" 
              className={`px-4 py-2.5 text-base font-medium rounded-full transition-all duration-300 ${
                isActive("/#about") 
                  ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" 
                  : "text-gray-700 hover:bg-gradient-to-r hover:from-[#FF7A47]/20 hover:to-[#29ABA4]/20"
              }`}
              onClick={(e) => {
                handleNavLinkClick(e, "/#about");
                setIsOpen(false);
              }}
            >
              À propos
            </a>
            <a 
              href="/#skills" 
              className={`px-4 py-2.5 text-base font-medium rounded-full transition-all duration-300 ${
                isActive("/#skills") 
                  ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" 
                  : "text-gray-700 hover:bg-gradient-to-r hover:from-[#FF7A47]/20 hover:to-[#29ABA4]/20"
              }`}
              onClick={(e) => {
                handleNavLinkClick(e, "/#skills");
                setIsOpen(false);
              }}
            >
              Mes compétences
            </a>
            <a 
              href="/#help" 
              className={`px-4 py-2.5 text-base font-medium rounded-full transition-all duration-300 ${
                isActive("/#help") 
                  ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" 
                  : "text-gray-700 hover:bg-gradient-to-r hover:from-[#FF7A47]/20 hover:to-[#29ABA4]/20"
              }`}
              onClick={(e) => {
                handleNavLinkClick(e, "/#help");
                setIsOpen(false);
              }}
            >
              Comment je peux aider
            </a>
            <a 
              href="/#pricing" 
              className={`px-4 py-2.5 text-base font-medium rounded-full transition-all duration-300 ${
                isActive("/#pricing") 
                  ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" 
                  : "text-gray-700 hover:bg-gradient-to-r hover:from-[#FF7A47]/20 hover:to-[#29ABA4]/20"
              }`}
              onClick={(e) => {
                handleNavLinkClick(e, "/#pricing");
                setIsOpen(false);
              }}
            >
              Tarifs
            </a>
            <a 
              href="/#blog" 
              className={`px-4 py-2.5 text-base font-medium rounded-full transition-all duration-300 ${
                isActive("/#blog") 
                  ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" 
                  : "text-gray-700 hover:bg-gradient-to-r hover:from-[#FF7A47]/20 hover:to-[#29ABA4]/20"
              }`}
              onClick={(e) => {
                handleNavLinkClick(e, "/#blog");
                setIsOpen(false);
              }}
            >
              Blog
            </a>
            <a 
              href="/#contact" 
              className={`px-4 py-2.5 text-base font-medium rounded-full transition-all duration-300 ${
                isActive("/#contact") 
                  ? "bg-gradient-to-r from-[#FF7A47] to-[#29ABA4] text-white shadow-md" 
                  : "text-gray-700 hover:bg-gradient-to-r hover:from-[#FF7A47]/20 hover:to-[#29ABA4]/20"
              }`}
              onClick={(e) => {
                handleNavLinkClick(e, "/#contact");
                setIsOpen(false);
              }}
            >
              Contact
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
