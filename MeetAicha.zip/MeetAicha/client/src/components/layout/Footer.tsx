import { Link } from "wouter";
import AichaLogo from "@/assets/AichaLogo";
import { Mail, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-white pt-12 pb-8 border-t border-gray-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center mb-4">
              <div className="h-16 w-16 rounded-full overflow-hidden">
                <AichaLogo />
              </div>
              <span className="ml-3 text-2xl font-bold gradient-text font-poppins">Aïcha</span>
            </div>
            <p className="text-gray-600 mb-4">
              Votre employée digitale instantanée, disponible 24/7 pour répondre à vos questions et vous aider à naviguer dans le monde numérique.
            </p>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Liens rapides</h3>
            <ul className="space-y-2">
              <li><a href="/#about" className="text-gray-600 hover:text-[#FF7A47] transition-colors">À propos</a></li>
              <li><a href="/#skills" className="text-gray-600 hover:text-[#FF7A47] transition-colors">Mes compétences</a></li>
              <li><a href="/#help" className="text-gray-600 hover:text-[#FF7A47] transition-colors">Comment je peux aider</a></li>
              <li><a href="/#pricing" className="text-gray-600 hover:text-[#FF7A47] transition-colors">Tarification</a></li>
              <li><Link href="/blog" className="text-gray-600 hover:text-[#FF7A47] transition-colors">Blog</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Solutions</h3>
            <ul className="space-y-2">
              <li><a href="/#help" className="text-gray-600 hover:text-[#FF7A47] transition-colors">Pour les particuliers</a></li>
              <li><a href="/#help" className="text-gray-600 hover:text-[#FF7A47] transition-colors">Pour les entreprises</a></li>
              <li><a href="/#help" className="text-gray-600 hover:text-[#FF7A47] transition-colors">Pour les ONGs</a></li>
              <li><a href="/#help" className="text-gray-600 hover:text-[#FF7A47] transition-colors">Pour les gouvernements</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <Mail className="w-5 h-5 text-[#FF7A47] mt-1 mr-2" />
                <span>contact@aicha.ai</span>
              </li>
              <li className="flex items-start">
                <Phone className="w-5 h-5 text-[#FF7A47] mt-1 mr-2" />
                <span>+33 1 23 45 67 89</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 text-sm mb-4 md:mb-0">
            &copy; {new Date().getFullYear()} Aïcha. Tous droits réservés.
          </p>
          <div className="flex space-x-4">
            <a href="#" className="text-gray-600 hover:text-[#FF7A47] transition-colors text-sm">Politique de confidentialité</a>
            <a href="#" className="text-gray-600 hover:text-[#FF7A47] transition-colors text-sm">Conditions d'utilisation</a>
            <a href="#" className="text-gray-600 hover:text-[#FF7A47] transition-colors text-sm">Mentions légales</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
