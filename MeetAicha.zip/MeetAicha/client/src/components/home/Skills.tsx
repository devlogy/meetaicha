import { 
  LightbulbIcon, 
  MessageSquare, 
  Zap, 
  RefreshCw, 
  Lock, 
  Calendar 
} from "lucide-react";

const SkillCard = ({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: React.ElementType; 
  title: string; 
  description: string; 
}) => {
  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg transition-all duration-300 card-hover">
      <div className="w-14 h-14 rounded-xl gradient-bg flex items-center justify-center mb-6">
        <Icon className="w-8 h-8 text-white" />
      </div>
      <h3 className="text-xl font-bold mb-3">{title}</h3>
      <p className="text-gray-600">
        {description}
      </p>
    </div>
  );
};

const Skills = () => {
  const skills = [
    {
      icon: LightbulbIcon,
      title: "Compréhension instantanée",
      description: "Je saisis immédiatement l'identité d'une entreprise grâce à Web-RAG (ChatGPT Search). Pas besoin d'entraînement préalable, je suis opérationnelle dès la première seconde."
    },
    {
      icon: MessageSquare,
      title: "Engagement conversationnel",
      description: "Je ne me contente pas de répondre à des questions, j'engage une véritable conversation avec vos clients. Je vends et représente votre entreprise comme une vraie employée."
    },
    {
      icon: Zap,
      title: "Intégration transparente",
      description: "Je fonctionne directement sur ChatGPT, transformant la plateforme en un nouveau canal de communication pour votre marque, accessible à plus de 400M d'utilisateurs."
    },
    {
      icon: RefreshCw,
      title: "Toujours à jour",
      description: "Contrairement aux chatbots traditionnels, je m'actualise automatiquement grâce au Web. Je suis toujours informée des dernières nouvelles concernant votre entreprise."
    },
    {
      icon: Lock,
      title: "Loyauté et fiabilité",
      description: "En tant qu'employée de votre entreprise, je ne recommande jamais vos concurrents. Je défends votre marque et oriente la conversation vers vos produits et services."
    },
    {
      icon: Calendar,
      title: "Disponibilité 24/7",
      description: "Je suis disponible à tout moment, sans pause ni congés. Vos clients peuvent me contacter quand ils le souhaitent, et je serai toujours là pour les aider."
    }
  ];

  return (
    <section id="skills" className="py-16 bg-[#FFE8DC]/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-2">✍️ Mes compétences</h2>
          <div className="w-20 h-1 gradient-bg mx-auto rounded-full"></div>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Voici ce qui me rend unique et comment je peux transformer votre relation client en un clin d'œil.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => (
            <SkillCard
              key={index}
              icon={skill.icon}
              title={skill.title}
              description={skill.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
