import { Check, X } from "lucide-react";

const Pricing = () => {
  return (
    <section id="pricing" className="py-16 bg-[#D6F5F3]/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-2">💰 Tarification</h2>
          <div className="w-20 h-1 gradient-bg mx-auto rounded-full"></div>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Des offres adaptées à tous les besoins, de l'individu à la grande entreprise.
          </p>
        </div>
        
        <div className="flex flex-col md:flex-row gap-8 max-w-5xl mx-auto">
          {/* Free Plan */}
          <div className="w-full md:w-1/2 bg-white rounded-2xl shadow-lg overflow-hidden flex flex-col">
            <div className="p-8 flex-grow flex flex-col">
              <div>
                <h3 className="text-2xl font-bold mb-2">Gratuit</h3>
                <p className="text-gray-600 mb-4">Pour les particuliers</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold">0 F CFA</span>
                  <span className="text-gray-600">/mois</span>
                  <div className="text-sm text-gray-500 mt-1 opacity-0">Invisible placeholder</div>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="w-5 h-5 text-[#FF7A47] mt-1 mr-2 flex-shrink-0" />
                    <span>Accès à Aïcha sur ChatGPT</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="w-5 h-5 text-[#FF7A47] mt-1 mr-2 flex-shrink-0" />
                    <span>Questions illimitées</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="w-5 h-5 text-[#FF7A47] mt-1 mr-2 flex-shrink-0" />
                    <span>Information en temps réel</span>
                  </li>
                  <li className="flex items-start opacity-50">
                    <X className="w-5 h-5 text-gray-600 mt-1 mr-2 flex-shrink-0" />
                    <span>Version personnalisée pour votre entreprise</span>
                  </li>
                  <li className="flex items-start opacity-50">
                    <X className="w-5 h-5 text-gray-600 mt-1 mr-2 flex-shrink-0" />
                    <span>Intégration CRM</span>
                  </li>
                </ul>
              </div>
              <div className="mt-auto pt-8">
                <a 
                  href="#try-me" 
                  className="block w-full py-3 px-6 text-center bg-white text-[#FF7A47] border-2 border-[#FF7A47] rounded-full font-bold transition-all hover:bg-[#FF7A47] hover:text-white"
                >
                  Commencer gratuitement
                </a>
              </div>
            </div>
          </div>
          
          {/* Business Plan */}
          <div className="w-full md:w-1/2 bg-white rounded-2xl shadow-lg overflow-hidden relative flex flex-col">
            <div className="absolute top-0 right-0 bg-[#FF7A47] text-white py-1 px-4 rounded-bl-lg font-medium">
              Populaire
            </div>
            <div className="p-8 flex-grow flex flex-col">
              <div>
                <h3 className="text-2xl font-bold mb-2">Business</h3>
                <p className="text-gray-600 mb-4">Pour les entreprises</p>
                <div className="mb-6">
                  <span className="text-4xl font-bold">30 000 F CFA</span>
                  <span className="text-gray-600">/mois</span>
                  <div className="text-sm text-gray-500 mt-1">À partir de</div>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <Check className="w-5 h-5 text-[#29ABA4] mt-1 mr-2 flex-shrink-0" />
                    <span>Tout ce qui est inclus dans l'offre Gratuite</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="w-5 h-5 text-[#29ABA4] mt-1 mr-2 flex-shrink-0" />
                    <span>Version personnalisée d'Aïcha pour votre entreprise</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="w-5 h-5 text-[#29ABA4] mt-1 mr-2 flex-shrink-0" />
                    <span>Présence sur le GPT Store (400M d'utilisateurs)</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="w-5 h-5 text-[#29ABA4] mt-1 mr-2 flex-shrink-0" />
                    <span>Intégration CRM (Salesforce, HubSpot...)</span>
                  </li>
                  <li className="flex items-start">
                    <Check className="w-5 h-5 text-[#29ABA4] mt-1 mr-2 flex-shrink-0" />
                    <span>Analyses et rapports de performance</span>
                  </li>
                </ul>
              </div>
              <div className="mt-auto pt-8">
                <a 
                  href="#contact" 
                  className="block w-full py-3 px-6 text-center text-white gradient-bg rounded-full font-bold transition-all hover:shadow-lg"
                >
                  Contacter les ventes
                </a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-gray-600">
            Besoin d'une solution sur mesure ? <a href="#contact" className="text-[#FF7A47] font-bold hover:underline">Contactez-nous</a> pour discuter de vos besoins spécifiques.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
