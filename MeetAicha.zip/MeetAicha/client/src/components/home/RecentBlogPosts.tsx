import { useQuery } from "@tanstack/react-query";
import { BlogPost } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { ArrowRight, Calendar } from "lucide-react";

const BlogPostCard = ({ post }: { post: BlogPost }) => {
  return (
    <article className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden flex flex-col h-full">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={post.imageUrl} 
          alt={post.title} 
          className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
        />
      </div>
      <div className="p-6 flex flex-col flex-grow">
        <div className="flex items-center text-gray-500 text-sm mb-3">
          <Calendar className="w-4 h-4 mr-1" />
          <span>{new Date(post.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
        </div>
        <h3 className="text-xl font-bold mb-3 line-clamp-2">{post.title}</h3>
        <p className="text-gray-600 mb-4 line-clamp-2 flex-grow">{post.excerpt}</p>
        <Link 
          href={`/blog/${post.slug}`} 
          className="inline-flex items-center text-[#FF7A47] font-medium hover:underline mt-auto"
        >
          Lire la suite <ArrowRight className="ml-1 h-4 w-4" />
        </Link>
      </div>
    </article>
  );
};

const RecentBlogPosts = () => {
  const { data: blogPosts, isLoading } = useQuery<BlogPost[]>({
    queryKey: ['/api/blog-posts'],
  });

  // Récupérer uniquement les 3 derniers articles
  const recentPosts = blogPosts?.slice(0, 3);

  return (
    <section id="blog" className="py-16 bg-gradient-to-b from-white to-[#D6F5F3]/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-2">📝 Blog d'Aïcha</h2>
          <div className="w-20 h-1 gradient-bg mx-auto rounded-full"></div>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Découvrez mes derniers articles sur l'intelligence artificielle, les assistants virtuels et comment ils transforment le service client.
          </p>
        </div>
        
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-white rounded-2xl shadow-md p-4">
                <Skeleton className="h-48 w-full rounded-xl mb-4" />
                <Skeleton className="h-4 w-1/4 mb-2" />
                <Skeleton className="h-6 w-3/4 mb-3" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-full mb-4" />
                <Skeleton className="h-4 w-1/3" />
              </div>
            ))}
          </div>
        ) : recentPosts && recentPosts.length > 0 ? (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {recentPosts.map((post) => (
                <BlogPostCard key={post.id} post={post} />
              ))}
            </div>
            <div className="mt-10 text-center">
              <Link 
                href="/blog" 
                className="gradient-bg text-white font-bold py-3 px-8 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 inline-flex items-center"
              >
                Voir tous les articles <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </div>
          </>
        ) : (
          <div className="text-center py-12 bg-white rounded-xl shadow-sm">
            <h3 className="text-xl font-bold mb-2">Aucun article pour le moment</h3>
            <p className="text-gray-600">
              Revenez bientôt pour découvrir mes premiers articles !
            </p>
          </div>
        )}
      </div>
    </section>
  );
};

export default RecentBlogPosts;