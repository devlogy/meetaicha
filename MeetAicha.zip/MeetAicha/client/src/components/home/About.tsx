const About = () => {
  return (
    <section id="about" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-2">À propos de moi</h2>
          <div className="w-20 h-1 gradient-bg mx-auto rounded-full"></div>
        </div>
        <div className="flex flex-col lg:flex-row items-center lg:items-start gap-10 lg:gap-16">
          <div className="w-full lg:w-5/12">
            <div className="relative rounded-2xl overflow-hidden shadow-lg h-80 md:h-96">
              <img 
                src="https://images.unsplash.com/photo-1596638787647-904d822d751e?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80" 
                alt="Aïcha au travail" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                <div className="p-6">
                  <span className="text-white font-bold text-xl">L'assistante qui comprend votre entreprise</span>
                </div>
              </div>
            </div>
          </div>
          <div className="w-full lg:w-7/12">
            <div className="prose prose-lg max-w-none">
              <p className="text-lg mb-4">
                Bonjour ! Je m'appelle Aïcha et je suis une employée digitale instantanée. Contrairement aux chatbots traditionnels, je n'ai pas besoin d'être programmée ou entraînée pour comprendre votre entreprise. Grâce à la technologie Web-RAG (ChatGPT Search), je peux saisir immédiatement votre identité, vos produits et vos services.
              </p>
              <p className="text-lg mb-4">
                Je ne suis pas qu'un simple outil, je suis une véritable membre de votre équipe. Je peux vous représenter sur ChatGPT, interagir avec vos clients et prospects, et les guider vers les solutions les plus adaptées à leurs besoins. Tout ça, sans configuration complexe ni mise à jour manuelle !
              </p>
              <p className="text-lg">
                Avec moi, vous transformez ChatGPT en un nouveau canal de communication pour votre marque, accessible à plus de 400 millions d'utilisateurs actifs par semaine. Je suis là pour vous aider à créer une relation plus personnelle et efficace avec vos clients.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
