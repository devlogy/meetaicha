import { Star } from "lucide-react";

interface Testimonial {
  image: string;
  name: string;
  position: string;
  rating: number;
  text: string;
}

const TestimonialCard = ({ testimonial }: { testimonial: Testimonial }) => {
  const { image, name, position, rating, text } = testimonial;
  
  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg transition-all duration-300 card-hover">
      <div className="flex items-center mb-4">
        <div className="w-14 h-14 rounded-full overflow-hidden mr-4">
          <img 
            src={image} 
            alt={`Portrait de ${name}`} 
            className="w-full h-full object-cover"
          />
        </div>
        <div>
          <h4 className="font-bold">{name}</h4>
          <p className="text-sm text-gray-600">{position}</p>
        </div>
      </div>
      <div className="mb-4">
        <div className="flex">
          {Array.from({ length: 5 }).map((_, index) => (
            <Star 
              key={index} 
              className={`w-5 h-5 ${index < rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} 
            />
          ))}
        </div>
      </div>
      <p className="text-gray-600 italic">
        {text}
      </p>
    </div>
  );
};

const Testimonials = () => {
  const testimonials: Testimonial[] = [
    {
      image: "https://images.unsplash.com/photo-1556157382-97eda2d62296?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      name: "Sophie Martin",
      position: "PDG, Martech Solutions",
      rating: 5,
      text: "\"Aïcha a transformé notre service client. Sans aucune configuration, elle a immédiatement compris notre offre et commencé à répondre aux questions de nos clients. Nous avons réduit nos coûts de support de 45% !\""
    },
    {
      image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      name: "Thomas Dubois",
      position: "Directeur Digital, LuxBrand",
      rating: 5,
      text: "\"Le plus impressionnant avec Aïcha, c'est sa capacité à vraiment saisir l'essence de notre marque et à la représenter fidèlement. Elle est devenue notre meilleure ambassadrice sur ChatGPT, générant plus de 200 leads qualifiés par mois.\""
    },
    {
      image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=80",
      name: "Amina Khadri",
      position: "Responsable Communication, EcoSolutions",
      rating: 5,
      text: "\"En tant qu'ONG, nous avions besoin d'une solution pour informer efficacement sur nos actions. Aïcha a parfaitement compris notre mission et communique nos valeurs avec justesse. Les dons ont augmenté de 30% depuis son déploiement !\""
    }
  ];
  
  return (
    <section id="testimonials" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-2">📈 Témoignages</h2>
          <div className="w-20 h-1 gradient-bg mx-auto rounded-full"></div>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Découvrez ce que mes utilisateurs disent de moi.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} testimonial={testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
