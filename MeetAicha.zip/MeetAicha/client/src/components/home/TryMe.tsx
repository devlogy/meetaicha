const TryMe = () => {
  return (
    <section id="try-me" className="py-16 bg-[#FFE8DC]/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-4">🚀 Essayez-moi gratuitement</h2>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Prêt à découvrir ce que je peux faire pour vous ? Cliquez sur le bouton ci-dessous pour me tester directement sur ChatGPT, sans inscription ni configuration !
          </p>
          <a 
            href="https://chat.openai.com/g/g-example-aicha" 
            target="_blank" 
            rel="noopener noreferrer" 
            className="inline-block gradient-bg text-white font-bold py-4 px-10 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 text-lg"
          >
            Discuter avec Aïcha maintenant
          </a>
        </div>
      </div>
    </section>
  );
};

export default TryMe;
