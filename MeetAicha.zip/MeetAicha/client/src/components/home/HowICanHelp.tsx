import { CheckCircle } from "lucide-react";
import { User, Building2, Heart, LandmarkIcon, GraduationCap, Mic } from "lucide-react";

interface HelpCategory {
  icon: React.ElementType;
  title: string;
  backgroundColor: string;
  checkColor: string;
  items: string[];
}

const HelpCategoryCard = ({ category }: { category: HelpCategory }) => {
  const { icon: Icon, title, backgroundColor, checkColor, items } = category;
  
  return (
    <div className={`${backgroundColor} rounded-2xl p-6 md:p-8 shadow-lg h-full`}>
      <div className="mb-6">
        <div className="w-16 h-16 rounded-full gradient-bg flex items-center justify-center mb-4">
          <Icon className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-2xl font-bold mb-2">{title}</h3>
      </div>
      <ul className="space-y-3">
        {items.map((item, index) => (
          <li key={index} className="flex items-start">
            <CheckCircle className={`w-5 h-5 ${checkColor} mt-1 mr-2 flex-shrink-0`} />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

const HowICanHelp = () => {
  const categories: HelpCategory[] = [
    {
      icon: User,
      title: "Pour les individus",
      backgroundColor: "bg-[#FFF8E0]/50",
      checkColor: "text-[#FF7A47]",
      items: [
        "Assistant personnel pour la recherche d'information",
        "Recherche et comparaison de produits et services",
        "Support pour vos questions quotidiennes",
        "Accès facilité aux services numériques"
      ]
    },
    {
      icon: Building2,
      title: "Pour les entreprises",
      backgroundColor: "bg-[#D6F5F3]/50",
      checkColor: "text-[#29ABA4]",
      items: [
        "Service client 24/7 sans formation préalable",
        "Génération et qualification de leads",
        "Nouvelle présence sur ChatGPT (400M d'utilisateurs)",
        "Intégration avec votre CRM (HubSpot, Salesforce...)"
      ]
    },
    {
      icon: Heart,
      title: "Pour les ONGs",
      backgroundColor: "bg-[#F1E8FF]/50",
      checkColor: "text-[#FF7A47]",
      items: [
        "Diffusion de votre mission et de vos valeurs",
        "Information sur vos actions et campagnes",
        "Recrutement de bénévoles et de donateurs",
        "Support pour répondre aux questions du public"
      ]
    },
    {
      icon: LandmarkIcon,
      title: "Pour les gouvernements",
      backgroundColor: "bg-[#FFE8DC]/50",
      checkColor: "text-[#29ABA4]",
      items: [
        "Information des citoyens sur les services publics",
        "Aide à la navigation dans les démarches administratives",
        "Communication sur les politiques publiques",
        "Recueil des retours et des besoins des citoyens"
      ]
    },
    {
      icon: GraduationCap,
      title: "Pour les écoles",
      backgroundColor: "bg-[#E6F7FF]/50",
      checkColor: "text-[#FF7A47]",
      items: [
        "Assistance aux étudiants pour leurs recherches",
        "Support administratif pour les équipes enseignantes",
        "Information sur les programmes et inscriptions",
        "Communication avec les parents et la communauté"
      ]
    },
    {
      icon: Mic,
      title: "Pour les influenceurs",
      backgroundColor: "bg-[#FFEBF5]/50",
      checkColor: "text-[#29ABA4]",
      items: [
        "Gestion de la relation avec votre audience",
        "Organisation de contenu et de calendriers éditoriaux",
        "Réponses personnalisées à vos abonnés",
        "Analyse et veille de votre secteur d'activité"
      ]
    }
  ];
  
  return (
    <section id="help" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-2">✨ Comment je peux vous aider</h2>
          <div className="w-20 h-1 gradient-bg mx-auto rounded-full"></div>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Je peux m'adapter à différents types d'organisations et répondre à des besoins variés.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => (
            <HelpCategoryCard key={index} category={category} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowICanHelp;
