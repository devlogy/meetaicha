import { 
  Facebook, 
  Twitter, 
  Instagram, 
  Linkedin, 
  MessageSquare, 
  Send 
} from "lucide-react";

interface SocialLink {
  name: string;
  icon: React.ElementType;
  url: string;
  bgColor: string;
}

const SocialFollow = () => {
  const socialLinks: SocialLink[] = [
    {
      name: "Facebook",
      icon: Facebook,
      url: "https://facebook.com/",
      bgColor: "bg-blue-600"
    },
    {
      name: "X",
      icon: Twitter,
      url: "https://twitter.com/",
      bgColor: "bg-black"
    },
    {
      name: "Instagram",
      icon: Instagram,
      url: "https://instagram.com/",
      bgColor: "bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600"
    },
    {
      name: "LinkedIn",
      icon: Linkedin,
      url: "https://linkedin.com/",
      bgColor: "bg-blue-700"
    },
    {
      name: "WhatsApp",
      icon: MessageSquare,
      url: "https://wa.me/123456789",
      bgColor: "bg-green-500"
    },
    {
      name: "Telegram",
      icon: Send,
      url: "https://t.me/username",
      bgColor: "bg-blue-500"
    }
  ];
  
  return (
    <section id="follow" className="py-16 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold font-poppins mb-2">📱 Suivez-moi</h2>
          <div className="w-20 h-1 gradient-bg mx-auto rounded-full"></div>
          <p className="mt-4 text-lg text-gray-600 max-w-3xl mx-auto">
            Restez connecté avec moi sur les réseaux sociaux pour recevoir les dernières actualités et mises à jour.
          </p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-6 md:gap-8">
          {socialLinks.map((link, index) => (
            <a 
              key={index} 
              href={link.url} 
              target="_blank" 
              rel="noopener noreferrer" 
              className="flex flex-col items-center p-4 rounded-xl bg-white shadow-md hover:shadow-lg transition-all duration-300 card-hover"
            >
              <div className={`w-14 h-14 rounded-full ${link.bgColor} flex items-center justify-center mb-3`}>
                <link.icon className="w-8 h-8 text-white" />
              </div>
              <span className="font-medium">{link.name}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialFollow;
