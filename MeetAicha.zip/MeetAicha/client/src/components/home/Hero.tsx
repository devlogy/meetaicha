import AichaLogo from "@/assets/AichaLogo";
import aichaPortraitPath from "@/assets/images/aicha-portrait.png";

const Hero = () => {
  return (
    <section className="py-16 md:py-24 bg-gradient-to-b from-white to-[#D6F5F3]">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row items-center">
          <div className="w-full lg:w-1/2 mb-10 lg:mb-0">
            <div className="text-center lg:text-left">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-poppins mb-6">
                <div className="flex items-start">
                  <span className="mr-4 text-5xl md:text-6xl">👋</span>
                  <div className="flex flex-col text-left">
                    <span className="text-gray-800">Bonjour,</span>
                    <div className="flex items-baseline mt-1">
                      <span className="text-gray-800">je suis</span>
                      <span className="gradient-text ml-3 text-5xl md:text-6xl lg:text-7xl">Aïcha</span>
                    </div>
                  </div>
                </div>
              </h1>
              <h2 className="text-2xl md:text-3xl font-bold mb-6">Votre employée digitale instantanée !</h2>
              <p className="text-lg text-gray-600 mb-8 max-w-lg mx-auto lg:mx-0">
                Je comprends votre entreprise instantanément et m'adapte à vos besoins sans configuration complexe. Laissez-moi révolutionner votre relation client !
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-4">
                <a 
                  href="#try-me" 
                  className="gradient-bg text-white font-bold py-3 px-8 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1"
                >
                  Essayez-moi gratuitement !
                </a>
                <a 
                  href="#about" 
                  className="bg-white text-[#FF7A47] border border-[#FF7A47] font-bold py-3 px-8 rounded-full shadow hover:shadow-md transition-all duration-300"
                >
                  En savoir plus
                </a>
              </div>
            </div>
          </div>
          <div className="w-full lg:w-1/2 flex justify-center lg:justify-end">
            <div className="relative w-80 h-auto md:w-[450px] rounded-2xl overflow-hidden shadow-xl bg-[#d8dfcb]">
              <img 
                src={aichaPortraitPath}
                alt="Aïcha, votre employée digitale" 
                className="w-full h-full object-contain"
              />
              <div className="absolute -bottom-2 -right-2 w-20 h-20 md:w-24 md:h-24 rounded-full bg-white p-2 shadow-lg">
                <div className="w-full h-full rounded-full overflow-hidden">
                  <AichaLogo />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
