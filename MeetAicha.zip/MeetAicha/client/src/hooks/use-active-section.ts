import { useState, useEffect } from 'react';

export function useActiveSection() {
  const [activeSection, setActiveSection] = useState<string>('about'); // Par défaut, c'est la section "about"

  useEffect(() => {
    // Liste des sections à observer (avec leurs IDs)
    const sections = [
      'about', 
      'skills', 
      'help', 
      'pricing', 
      'blog', 
      'contact'
    ];

    // Configurer l'Intersection Observer
    const observerOptions = {
      root: null, // viewport
      rootMargin: '-100px 0px -60% 0px', // Ajustez ces valeurs pour déterminer quand une section est considérée comme "visible"
      threshold: 0, // Déclenche dès qu'une partie de l'élément est visible
    };

    const observerCallback: IntersectionObserverCallback = (entries) => {
      entries.forEach((entry) => {
        // Si la section est visible et intersecte avec la fenêtre
        if (entry.isIntersecting) {
          const id = entry.target.id;
          setActiveSection(id);
        }
      });
    };

    // Créer l'observer
    const observer = new IntersectionObserver(observerCallback, observerOptions);

    // Observer toutes les sections
    sections.forEach((sectionId) => {
      const element = document.getElementById(sectionId);
      if (element) {
        observer.observe(element);
      }
    });

    // Nettoyer l'observer lors du démontage
    return () => {
      sections.forEach((sectionId) => {
        const element = document.getElementById(sectionId);
        if (element) {
          observer.unobserve(element);
        }
      });
    };
  }, []);

  return activeSection;
}