import { useEffect } from 'react';

// Fonction utilitaire pour scroller vers un élément de manière fluide
export function scrollToElement(href: string): boolean {
  // Pour calculer le décalage en tenant compte de la hauteur du header et d'un espace supplémentaire
  const getOffset = () => {
    // Hauteur du header fixe (la barre de navigation)
    const header = document.querySelector('nav');
    const headerHeight = header ? header.offsetHeight : 0;
    
    // Ajouter un espace supplémentaire pour une meilleure lisibilité (20px)
    return headerHeight + 20;
  };

  // Fonction de défilement avec offset
  const scrollWithOffset = (element: HTMLElement) => {
    const offset = getOffset();
    const elementPosition = element.getBoundingClientRect().top;
    const offsetPosition = elementPosition + window.pageYOffset - offset;
    
    window.scrollTo({
      top: offsetPosition,
      behavior: 'smooth'
    });
  };
  
  // Si c'est un lien d'ancrage sur la page actuelle
  if (href.startsWith('#') && href.length > 1) {
    const targetId = href.substring(1);
    const targetElement = document.getElementById(targetId);
    
    if (targetElement) {
      // Défilement avec offset
      scrollWithOffset(targetElement);
      
      // Mise à jour de l'URL sans rechargement de la page
      history.pushState(null, '', href);
      return true;
    }
  } else if (href.includes('#') && href.indexOf('#') > 0) {
    // Pour les liens comme "/#about"
    const parts = href.split('#');
    const isCurrentPage = window.location.pathname === parts[0] || 
                         (parts[0] === '/' && window.location.pathname === '');
    
    if (isCurrentPage && parts[1].length > 0) {
      const targetId = parts[1];
      const targetElement = document.getElementById(targetId);
      
      if (targetElement) {
        // Défilement avec offset
        scrollWithOffset(targetElement);
        
        // Mise à jour de l'URL sans rechargement de la page
        history.pushState(null, '', `#${targetId}`);
        return true;
      }
    }
  }
  
  return false;
}

export function useSmoothScroll() {
  useEffect(() => {
    // Fonction pour gérer le défilement fluide
    const handleSmoothScroll = (e: MouseEvent) => {
      // Vérifier si l'élément cliqué est un lien et s'il pointe vers un ID sur la page actuelle
      const target = e.target as HTMLElement;
      const link = target.closest('a');
      
      if (!link) return;
      
      const href = link.getAttribute('href');
      if (!href) return;
      
      // Utiliser la fonction utilitaire pour scroll
      if (scrollToElement(href)) {
        e.preventDefault();
      }
    };
    
    // Ajouter l'écouteur d'événement sur le document
    document.addEventListener('click', handleSmoothScroll);
    
    // Nettoyer l'écouteur d'événement lors du démontage du composant
    return () => {
      document.removeEventListener('click', handleSmoothScroll);
    };
  }, []);
}