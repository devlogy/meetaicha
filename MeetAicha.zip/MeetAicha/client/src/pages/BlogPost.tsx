import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useRoute } from "wouter";
import { ArrowLeft, Calendar, Clock } from "lucide-react";
import { BlogPost } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";

const BlogPostDetail = () => {
  const [, params] = useRoute("/blog/:slug");
  const slug = params?.slug;

  const { data: post, isLoading, isError } = useQuery<BlogPost>({
    queryKey: [`/api/blog-posts/${slug}`],
    enabled: !!slug,
  });

  useEffect(() => {
    if (post) {
      document.title = `${post.title} - Meet Aïcha`;
    } else {
      document.title = "Article - Meet Aïcha";
    }
  }, [post]);

  // Fonction pour estimer le temps de lecture (environ 200 mots par minute)
  const calculateReadingTime = (content: string) => {
    const wordCount = content.split(/\s+/).length;
    const readingTime = Math.ceil(wordCount / 200);
    return readingTime > 0 ? readingTime : 1; // Minimum 1 minute
  };

  if (isLoading) {
    return (
      <div className="bg-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <div className="mb-8">
            <Link href="/blog" className="inline-flex items-center text-[#FF7A47] hover:underline mb-6">
              <ArrowLeft className="mr-2 h-4 w-4" /> Retour aux articles
            </Link>
            <Skeleton className="h-10 w-3/4 mb-4" />
            <div className="flex items-center space-x-4 mb-6">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-32" />
            </div>
            <Skeleton className="h-64 w-full rounded-xl mb-8" />
            <div className="space-y-4">
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-full" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (isError || !post) {
    return (
      <div className="bg-white py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          <div className="text-center py-12 bg-gray-50 rounded-xl">
            <h2 className="text-2xl font-bold mb-4">Article non trouvé</h2>
            <p className="text-gray-600 mb-6">
              L'article que vous recherchez n'existe pas ou a été supprimé.
            </p>
            <Link href="/blog" className="inline-flex items-center text-[#FF7A47] font-medium hover:underline">
              <ArrowLeft className="mr-2 h-4 w-4" /> Retour à la liste des articles
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const readingTime = calculateReadingTime(post.content);

  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        <div className="mb-8">
          <Link href="/blog" className="inline-flex items-center text-[#FF7A47] hover:underline mb-6">
            <ArrowLeft className="mr-2 h-4 w-4" /> Retour aux articles
          </Link>
          <h1 className="text-3xl md:text-4xl font-bold mb-4">{post.title}</h1>
          <div className="flex flex-wrap items-center text-gray-500 text-sm mb-8 gap-4">
            <div className="flex items-center">
              <Calendar className="w-4 h-4 mr-1" />
              <span>{new Date(post.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
            </div>
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              <span>{readingTime} min de lecture</span>
            </div>
          </div>
          <div className="rounded-xl overflow-hidden mb-8 shadow-md">
            <img 
              src={post.imageUrl} 
              alt={post.title} 
              className="w-full h-auto object-cover"
            />
          </div>
          <div className="prose prose-lg max-w-none">
            {/* On divise le contenu en paragraphes */}
            {post.content.split('\n\n').map((paragraph, index) => (
              <p key={index}>{paragraph}</p>
            ))}
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-8 mt-8">
          <h3 className="text-xl font-bold mb-4">Vous pourriez aussi aimer</h3>
          <Link 
            href="/blog" 
            className="gradient-bg text-white font-bold py-3 px-8 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 inline-flex items-center"
          >
            Voir tous les articles <ArrowLeft className="ml-2 h-5 w-5 rotate-180" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default BlogPostDetail;