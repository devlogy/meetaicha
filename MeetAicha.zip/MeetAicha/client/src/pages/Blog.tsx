import { useEffect, useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { BlogPost } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowRight } from "lucide-react";

const Blog = () => {
  useEffect(() => {
    document.title = "Blog - Meet Aïcha";
  }, []);

  const { data: blogPosts, isLoading } = useQuery<BlogPost[]>({
    queryKey: ['/api/blog-posts'],
  });

  return (
    <div className="bg-white py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Blog d'Aïcha</h1>
          <div className="w-20 h-1 gradient-bg mx-auto rounded-full mb-6"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Découvrez mes derniers articles sur l'intelligence artificielle, les assistants virtuels et comment ils transforment le service client.
          </p>
        </div>

        <div className="max-w-5xl mx-auto">
          {isLoading ? (
            // Loading skeletons
            <div className="space-y-10">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex flex-col md:flex-row gap-8">
                  <div className="w-full md:w-1/3">
                    <Skeleton className="h-48 w-full rounded-xl" />
                  </div>
                  <div className="w-full md:w-2/3 space-y-3">
                    <Skeleton className="h-8 w-3/4" />
                    <Skeleton className="h-4 w-1/4" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-full" />
                    <Skeleton className="h-4 w-2/3" />
                    <Skeleton className="h-10 w-36 mt-4" />
                  </div>
                </div>
              ))}
            </div>
          ) : blogPosts && blogPosts.length > 0 ? (
            <div className="space-y-10">
              {blogPosts.map((post) => (
                <article key={post.id} className="flex flex-col md:flex-row gap-8 bg-white p-6 rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="w-full md:w-1/3">
                    <img 
                      src={post.imageUrl} 
                      alt={post.title} 
                      className="w-full h-48 object-cover rounded-xl"
                    />
                  </div>
                  <div className="w-full md:w-2/3">
                    <h2 className="text-2xl font-bold mb-2">{post.title}</h2>
                    <p className="text-sm text-gray-500 mb-3">{new Date(post.date).toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
                    <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt}</p>
                    <Link 
                      href={`/blog/${post.slug}`} 
                      className="inline-flex items-center text-[#FF7A47] font-medium hover:underline"
                    >
                      Lire la suite <ArrowRight className="ml-1 h-4 w-4" />
                    </Link>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-gray-50 rounded-xl">
              <h3 className="text-xl font-bold mb-2">Aucun article pour le moment</h3>
              <p className="text-gray-600">
                Revenez bientôt pour découvrir mes premiers articles !
              </p>
              <Link href="/" className="inline-block mt-6 text-[#FF7A47] font-medium hover:underline">
                Retour à l'accueil
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Blog;
