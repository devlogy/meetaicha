import Hero from "@/components/home/Hero";
import About from "@/components/home/About";
import Skills from "@/components/home/Skills";
import HowICanHelp from "@/components/home/HowICanHelp";
import Pricing from "@/components/home/Pricing";
import Testimonials from "@/components/home/Testimonials";
import TryMe from "@/components/home/TryMe";
import SocialFollow from "@/components/home/SocialFollow";
import ContactForm from "@/components/home/ContactForm";
import RecentBlogPosts from "@/components/home/RecentBlogPosts";
import { useEffect } from "react";

const Home = () => {
  useEffect(() => {
    document.title = "Meet Aïcha - Votre Employée Digitale Instantanée";
  }, []);

  return (
    <>
      <Hero />
      <About />
      <Skills />
      <HowICanHelp />
      <Pricing />
      <Testimonials />
      <RecentBlogPosts />
      <TryMe />
      <SocialFollow />
      <ContactForm />
    </>
  );
};

export default Home;
