import aichaLogoPath from "./images/aicha-logo.png";

export const AichaLogo = () => {
  return (
    <img 
      src={aichaLogoPath} 
      alt="Aïcha Logo" 
      className="w-full h-full object-contain"
    />
  );
};

export default AichaLogo;
