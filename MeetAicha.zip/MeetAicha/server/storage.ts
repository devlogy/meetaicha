import { 
  users, 
  type User, 
  type InsertUser, 
  blogPosts, 
  type BlogPost, 
  type InsertBlogPost,
  contacts,
  type Contact,
  type InsertContact
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Blog post operations
  getBlogPosts(): Promise<BlogPost[]>;
  getBlogPostById(id: number): Promise<BlogPost | undefined>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  createBlogPost(blogPost: InsertBlogPost): Promise<BlogPost>;
  
  // Contact operations
  createContact(contact: InsertContact): Promise<Contact>;
  getContacts(): Promise<Contact[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private blogPosts: Map<number, BlogPost>;
  private contacts: Map<number, Contact>;
  private currentUserId: number;
  private currentBlogPostId: number;
  private currentContactId: number;

  constructor() {
    this.users = new Map();
    this.blogPosts = new Map();
    this.contacts = new Map();
    this.currentUserId = 1;
    this.currentBlogPostId = 1;
    this.currentContactId = 1;
    
    // Add some sample blog posts
    this.createBlogPost({
      title: "Comment l'IA révolutionne le service client",
      slug: "ia-revolution-service-client",
      excerpt: "Découvrez comment l'intelligence artificielle transforme l'expérience client et permet aux entreprises d'offrir un support 24/7 sans coûts supplémentaires.",
      content: "Contenu complet de l'article...",
      imageUrl: "https://images.unsplash.com/photo-1560472355-536de3962603?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
    });
    
    this.createBlogPost({
      title: "Web-RAG : comprendre la technologie derrière Aïcha",
      slug: "web-rag-technologie-aicha",
      excerpt: "Web-RAG (Retrieval-Augmented Generation) est la technologie qui permet à Aïcha de comprendre instantanément votre entreprise. Explorons son fonctionnement et ses avantages.",
      content: "Contenu complet de l'article...",
      imageUrl: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
    });
    
    this.createBlogPost({
      title: "Comment intégrer un assistant IA dans votre stratégie marketing",
      slug: "integrer-assistant-ia-strategie-marketing",
      excerpt: "Les assistants IA comme Aïcha offrent de nouvelles opportunités pour enrichir votre stratégie marketing. Voici comment les utiliser efficacement.",
      content: "Contenu complet de l'article...",
      imageUrl: "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-1.2.1&auto=format&fit=crop&w=1000&q=80",
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Blog post operations
  async getBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values()).sort((a, b) => 
      new Date(b.date).getTime() - new Date(a.date).getTime()
    );
  }
  
  async getBlogPostById(id: number): Promise<BlogPost | undefined> {
    return this.blogPosts.get(id);
  }
  
  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    return Array.from(this.blogPosts.values()).find(
      (post) => post.slug === slug
    );
  }
  
  async createBlogPost(insertBlogPost: InsertBlogPost): Promise<BlogPost> {
    const id = this.currentBlogPostId++;
    const now = new Date();
    const blogPost: BlogPost = { 
      ...insertBlogPost, 
      id, 
      date: now
    };
    this.blogPosts.set(id, blogPost);
    return blogPost;
  }
  
  // Contact operations
  async createContact(insertContact: InsertContact): Promise<Contact> {
    const id = this.currentContactId++;
    const now = new Date();
    const contact: Contact = {
      ...insertContact,
      id,
      createdAt: now
    };
    this.contacts.set(id, contact);
    return contact;
  }
  
  async getContacts(): Promise<Contact[]> {
    return Array.from(this.contacts.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }
}

export const storage = new MemStorage();
