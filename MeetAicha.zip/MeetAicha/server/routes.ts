import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertContactSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  // Get all blog posts
  app.get("/api/blog-posts", async (req, res) => {
    try {
      const blogPosts = await storage.getBlogPosts();
      res.json(blogPosts);
    } catch (error) {
      res.status(500).json({ message: "Une erreur est survenue lors de la récupération des articles de blog" });
    }
  });
  
  // Get a blog post by slug
  app.get("/api/blog-posts/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const blogPost = await storage.getBlogPostBySlug(slug);
      
      if (!blogPost) {
        return res.status(404).json({ message: "Article non trouvé" });
      }
      
      res.json(blogPost);
    } catch (error) {
      res.status(500).json({ message: "Une erreur est survenue lors de la récupération de l'article" });
    }
  });
  
  // Submit contact form
  app.post("/api/contact", async (req, res) => {
    try {
      const contactData = insertContactSchema.parse(req.body);
      
      const contact = await storage.createContact(contactData);
      
      res.status(201).json({
        message: "Message envoyé avec succès",
        contact: {
          id: contact.id,
          createdAt: contact.createdAt
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Données invalides", 
          errors: error.errors 
        });
      }
      
      res.status(500).json({ message: "Une erreur est survenue lors de l'envoi du message" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
